from fastapi import FastAPI, Depends
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Подключаем текущую папку как раздачу статических файлов (для отдачи вашего HTML)
app.mount("/static", StaticFiles(directory="."), name="static")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/api/services")
def get_services(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    services = db.query(models.MedicalService).offset(skip).limit(limit).all()
    return services