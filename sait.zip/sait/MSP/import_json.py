import json
import psycopg2
from pathlib import Path

# НАСТРОЙКИ ПОДКЛЮЧЕНИЯ К БАЗЕ ДАННЫХ (UTF-8)
DB_CONFIG = {
    "dbname": "med_database", 
    "user": "postgres",
    "password": "ТВОИ ДАННЫЕ",
    "host": "localhost",
    "port": "5432"
}

def import_prices():
    output_dir = Path("output")
    json_files = sorted(output_dir.glob("prices_*.json"))
    
    if not json_files:
        print("[-] Файлы с ценами не найдены. Сначала запустите med_parser.py")
        return
        
    latest_file = json_files[-1]
    print(f"[+] Читаем файл: {latest_file}")
    
    # Используем utf-8-sig, чтобы автоматически убрать невидимый BOM-байт, ломающий декодирование в Windows
    with open(latest_file, "r", encoding="utf-8-sig") as f:
        services = json.load(f)
        
    print(f"[~] Загружено записей для импорта: {len(services)}")
    
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        
        # Устанавливаем кодировку соединения
        cur.execute("SET client_encoding = 'UTF8';")
        
        cur.execute("""
            CREATE TABLE IF NOT EXISTS medical_services (
                service_id VARCHAR(50) PRIMARY KEY,
                clinic_id VARCHAR(50),
                clinic_name VARCHAR(255),
                city VARCHAR(100),
                address VARCHAR(255),
                source_url TEXT,
                service_name_raw TEXT,
                category VARCHAR(100),
                price_kzt INTEGER,
                currency VARCHAR(10),
                parsed_at TIMESTAMP
            )
        """)
        
        query = """
            INSERT INTO medical_services 
            (service_id, clinic_id, clinic_name, city, address, source_url, service_name_raw, category, price_kzt, currency, parsed_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (service_id) DO UPDATE 
            SET price_kzt = EXCLUDED.price_kzt, 
                parsed_at = EXCLUDED.parsed_at;
        """
        
        count = 0
        for s in services:
            cur.execute(query, (
                s.get("service_id"),
                s.get("clinic_id"),
                s.get("clinic_name"),
                s.get("city"),
                s.get("address"),
                s.get("source_url"),
                s.get("service_name_raw"),
                s.get("category"),
                s.get("price_kzt"),
                s.get("currency"),
                s.get("parsed_at")
            ))
            count += 1
            
        conn.commit()
        print(f"[✓] УСПЕШНО ИМПОРТИРОВАНО В POSTGRESQL: {count} строк!")
        
        cur.close()
        conn.close()
        
    except Exception as e:
        print(f"[-] Ошибка подключения к базе данных или выполнения запроса: {e}")

if __name__ == "__main__":
    import_prices()