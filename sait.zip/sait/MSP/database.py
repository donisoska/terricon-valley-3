from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Строка подключения (ваши данные из import_json.py)
SQLALCHEMY_DATABASE_URL = "postgresql://postgres:ТВОИ ДАННЫЕ@localhost:ТВОИ ДАННЫЕ/med_database"

# Создаем движок (engine) для работы с базой
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# Фабрика сессий для выполнения запросов
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Базовый класс для моделей таблиц
Base = declarative_base()