from sqlalchemy import Column, Integer, String, Text, TIMESTAMP
from database import Base

class MedicalService(Base):
    __tablename__ = "medical_services"

    service_id = Column(String(50), primary_key=True, index=True)
    clinic_id = Column(String(50))
    clinic_name = Column(String(255))
    city = Column(String(100))
    address = Column(String(255))
    source_url = Column(Text)
    service_name_raw = Column(Text)
    category = Column(String(100))
    price_kzt = Column(Integer)
    currency = Column(String(10))
    parsed_at = Column(TIMESTAMP)