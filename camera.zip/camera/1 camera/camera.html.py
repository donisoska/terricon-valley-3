import cv2
from ultralytics import YOLO


def run_ai_camera():
    # 1. Указываем путь к обученной модели
    # Если ты запускаешь скрипт из другой папки, укажи полный (абсолютный) путь
    model_path = "C:\Users\Admin\OneDrive\Desktop\New folder\best.pt"

    print("Загрузка обученной MedTech модели...")
    model = YOLO(model_path)

    # 2. Подключаемся к веб-камере (0 — это стандартная встроенная камера)
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Ошибка: Не удалось открыть веб-камеру.")
        return

    print("\nКамера успешно запущена!")
    print("Для выхода из программы нажмите клавишу 'Q' на английской раскладке.")

    while True:
        # Считываем текущий кадр с камеры
        ret, frame = cap.read()
        if not ret:
            print("Ошибка приема кадра.")
            break

        # 3. Передаем кадр в нашу нейросеть
        # verbose=False отключает лишний спам в консоль
        results = model(frame, verbose=False)

        for result in results:
            # Получаем индекс самого вероятного класса и его название
            top1_idx = result.probs.top1
            class_name = result.names[top1_idx]

            # Получаем уверенность модели (от 0.0 до 1.0)
            confidence = result.probs.top1conf.item()

            # Красивое форматирование текста для экрана
            text = f"{class_name}: {confidence * 100:.1f}%"

            # Меняем цвет текста: зеленый для маски, красный — если без неё
            # В OpenCV цвета задаются в формате BGR (Синий, Зеленый, Красный)
            if class_name == "with_mask":
                color = (0, 255, 0)  # Зеленый
            else:
                color = (0, 0, 255)  # Красный

            # 4. Рисуем текст прямо поверх видеопотока
            cv2.putText(
                frame,
                text,
                (30, 50),  # Координаты (X, Y) где начнется текст
                cv2.FONT_HERSHEY_SIMPLEX,  # Шрифт
                1.2,  # Размер шрифта
                color,  # Цвет
                3,  # Толщина линий шрифта
                cv2.LINE_AA
            )

        # Выводим измененный кадр в окно
        cv2.imshow("MedTech - Face Mask Detector AI", frame)

        # Ждем нажатия клавиши 'q' для выхода
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Освобождаем ресурсы камеры и закрываем окна
    cap.release()
    cv2.destroyAllWindows()
    print("Программа успешно завершена.")


if __name__ == "__main__":
    run_ai_camera()