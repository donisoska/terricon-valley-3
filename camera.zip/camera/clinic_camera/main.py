import cv2
import os
import sqlite3
import numpy as np
import time
from ultralytics import YOLO

# Инициализация базы данных SQLite
conn = sqlite3.connect("clinic.db")
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS visitors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hist_data BLOB,
        first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        visit_count INTEGER DEFAULT 1
    )
''')
conn.commit()

# Загружаем модель YOLO
model = YOLO("yolov8n.pt")

# Инициализация камеры
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# Трекер и таймеры
appearance_time = {}   # ID трекера -> время появления
saved_faces = {}        # ID трекера -> список кадров лиц
counted_in_ids = set() # Посчитанные на вход
counted_out_ids = set()# Посчитанные на выход

# Глобальная память посещений (ID из БД -> timestamp)
last_seen_global = {}

my_tracker = {}
next_object_id = 1
count_in = 0
count_out = 0

def process_face_and_get_id(face_images):
    """Супер-безопасный анализ на чистом NumPy (без вылетов cv2.compareHist)"""
    if not face_images:
        return None
        
    valid_hist_count = 0
    # Создаем плоский массив на 4096 элементов (16x16x16)
    avg_hist = np.zeros((4096,), dtype=np.float32)
    
    for img in face_images:
        if img is None or img.size == 0 or img.shape[0] < 10 or img.shape[1] < 10:
            continue
        try:
            # Считаем гистограмму и сразу превращаем в одномерный массив
            hist = cv2.calcHist([img], [0, 1, 2], None, [16, 16, 16], [0, 256, 0, 256, 0, 256])
            hist = hist.flatten()
            
            # Нормализация вручную через чистый NumPy
            norm = np.linalg.norm(hist)
            if norm > 0:
                hist = hist / norm
                
            avg_hist += hist
            valid_hist_count += 1
        except Exception:
            continue

    if valid_hist_count == 0:
        return None
        
    avg_hist /= valid_hist_count
    # Финальная нормализация среднего вектора
    final_norm = np.linalg.norm(avg_hist)
    if final_norm > 0:
        avg_hist = avg_hist / final_norm

    cursor.execute("SELECT id, hist_data FROM visitors")
    rows = cursor.fetchall()
    
    match_found = False
    visitor_id = None

    for row in rows:
        db_id, db_hist_blob = row
        # Десериализуем строго в float32
        db_hist = np.frombuffer(db_hist_blob, dtype=np.float32)
        
        # Проверка на совпадение размеров массивов во избежание краша
        if db_hist.shape != avg_hist.shape:
            continue
            
        # Считаем скалярное произведение векторов (косинусное сходство) через NumPy. 
        # Это работает стабильнее и никогда не вешает систему.
        similarity = float(np.dot(avg_hist, db_hist))
        
        # Для косинусного сходства нормализованных векторов 0.50 — это хороший порог совпадения
        if similarity > 0.50:
            match_found = True
            visitor_id = db_id
            break

    current_time = time.time()

    if match_found:
        last_time = last_seen_global.get(visitor_id, 0)
        if current_time - last_time > 10.0:
            cursor.execute("UPDATE visitors SET last_seen = CURRENT_TIMESTAMP, visit_count = visit_count + 1 WHERE id = ?", (visitor_id,))
            conn.commit()
            print(f"🔄 Узнал! Клиент #{visitor_id} вернулся (прошло больше 10 сек).")
        
        last_seen_global[visitor_id] = current_time
        return visitor_id
    else:
        cursor.execute("INSERT INTO visitors (hist_data) VALUES (?)", (avg_hist.tobytes(),))
        conn.commit()
        new_id = cursor.lastrowid
        last_seen_global[new_id] = current_time
        print(f"✨ Новый клиент зарегистрирован под ID #{new_id}")
        return new_id

print("🚀 Запущена бронебойная версия. Сравнение перенесено на NumPy.")

while cap.isOpened():
    success, frame = cap.read()
    if not success or frame is None:
        continue

    height, width, _ = frame.shape
    exit_line_x = int(width * 0.82) # Линия выхода справа

    results = model(frame, classes=[0], verbose=False)
    current_frame_centroids = []
    
    if results and results[0].boxes is not None:
        boxes = results[0].boxes.xyxy.cpu().numpy()
        for box in boxes:
            x1, y1, x2, y2 = box
            cx = int((x1 + x2) / 2)
            cy = int((y1 + y2) / 2)
            current_frame_centroids.append((cx, cy, box))

    new_tracker = {}
    current_time = time.time()

    for cx, cy, box in current_frame_centroids:
        assigned_id = None
        min_distance = 80
        
        for obj_id, last_y in my_tracker.items():
            if abs(cy - last_y) < min_distance:
                assigned_id = obj_id
                break
                
        if assigned_id is None:
            assigned_id = next_object_id
            next_object_id += 1
            appearance_time[assigned_id] = current_time
            saved_faces[assigned_id] = []

        new_tracker[assigned_id] = cy
        x1, y1, x2, y2 = box

        elapsed = current_time - appearance_time[assigned_id]
        
        if assigned_id not in counted_in_ids:
            if elapsed < 5.0:
                box_height = y2 - y1
                face_crop = frame[max(0, int(y1)):max(0, int(y1 + (box_height * 0.45))), max(0, int(x1)):min(width, int(x2))]
                if face_crop.size > 0:
                    saved_faces[assigned_id].append(face_crop.copy())
                
                cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (255, 255, 0), 2)
                cv2.putText(frame, f"Scanning: {int(5 - elapsed)}s", (int(x1), int(y1) - 10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
            else:
                db_user_id = process_face_and_get_id(saved_faces[assigned_id])
                counted_in_ids.add(assigned_id)
                count_in += 1
        else:
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
            cv2.putText(frame, "CLIENT IN", (int(x1), int(y1) - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        if cx > exit_line_x and assigned_id not in counted_out_ids:
            if assigned_id in counted_in_ids:
                counted_out_ids.add(assigned_id)
                count_out += 1
                print(f"📤 ID {assigned_id} вышел направо. OUT +1.")

    my_tracker = new_tracker

    # Интерфейс
    cv2.line(frame, (exit_line_x, 0), (exit_line_x, height), (0, 0, 255), 2)
    cv2.putText(frame, "EXIT TO RIGHT >>", (exit_line_x - 150, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
    
    cv2.putText(frame, f"Unique IN: {count_in}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.putText(frame, f"OUT: {count_out}", (20, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    cv2.imshow("Clinic AI Analytics Pro", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
conn.close()