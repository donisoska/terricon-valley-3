import sqlite3
from datetime import datetime

# Подключаемся к нашей базе данных
conn = sqlite3.connect("clinic.db")
cursor = conn.cursor()

print("=" * 50)
print("📊 АНАЛИТИКА ПОПУЛЯРНОСТИ КЛИНИКИ")
print("=" * 50)

# 1. Считаем общее количество уникальных посетителей в базе
cursor.execute("SELECT COUNT(*) FROM visitors")
total_unique = cursor.fetchone()[0]
print(f"✨ Всего уникальных клиентов в базе: {total_unique}")

# 2. Считаем повторные визиты (клиенты, которые вернулись)
cursor.execute("SELECT COUNT(*) FROM visitors WHERE visit_count > 1")
returning_visitors = cursor.fetchone()[0]
print(f"🔄 Из них возвращались более одного раза: {returning_visitors}")

if total_unique > 0:
    loyalty_rate = (returning_visitors / total_unique) * 100
    print(f"📈 Коэффициент возвращаемости (Лояльность): {loyalty_rate:.1f}%")
else:
    print("📈 Коэффициент возвращаемости: 0%")

print("-" * 50)
print("🕒 АНАЛИЗ ПИКОВЫХ ЧАСОВ НАГРУЗКИ (Когда идут люди):")

# 3. Анализируем время первого входа
cursor.execute("SELECT first_seen FROM visitors")
rows = cursor.fetchall()

# Словарь для подсчета людей по часам суток (от 00:00 до 23:00)
hourly_traffic = {i: 0 for i in range(24)}

for row in rows:
    timestamp_str = row[0]
    # Время в БД сохраняется как "2026-06-28 12:34:56"
    try:
        dt = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
        hourly_traffic[dt.hour] += 1
    except:
        try:
            # На случай другого формата SQLite
            hour = int(timestamp_str.split()[1].split(":")[0])
            hourly_traffic[hour] += 1
        except:
            continue

# Выводим текстовый график нагрузки клиники
has_data = False
for hour, count in hourly_traffic.items():
    if count > 0:
        has_data = True
        # Рисуем шкалу звездочками для наглядности
        graph_bar = "◼️" * count
        print(f"С {hour:02d}:00 до {hour+1:02d}:00 -> {count} чел. {graph_bar}")

if not has_data:
    print("Пока нет данных о часах посещений. Накапливайте статистику в main.py!")

print("=" * 50)

conn.close()