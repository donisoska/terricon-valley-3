# MedServicePrice.kz — Telegram Bot

Бот для сравнения цен на медицинские услуги в клиниках Казахстана.

---

## БЫСТРЫЙ СТАРТ (5 шагов)

### Шаг 1 — Получи токен бота

1. Открой Telegram, найди **@BotFather**
2. Напиши `/newbot`
3. Придумай имя бота, например: `MedServicePrice KZ`
4. Придумай username (латиница + цифры, оканчивается на `bot`), например: `medserviceprice_bot`
5. BotFather пришлёт токен вида: `1234567890:AAABBBCCC...`
6. Скопируй токен — он нужен на Шаге 3

---

### Шаг 2 — Установи Python

Нужен Python 3.11 или 3.12.

- **Windows:** скачай с https://www.python.org/downloads/
  При установке **обязательно** поставь галочку "Add Python to PATH"
- **Mac:** Python обычно уже есть. Проверь: `python3 --version`

---

### Шаг 3 — Вставь токен

Открой файл **`bot.py`** в любом редакторе (Notepad, VS Code, PyCharm).

Найди строку:
```python
BOT_TOKEN = "ВСТАВЬ_ТОКЕН_СЮДА"
```

Замени на свой токен:
```python
BOT_TOKEN = "1234567890:AAABBBCCC_твой_токен"
```

Сохрани файл.

---

### Шаг 4 — Установи зависимости

Открой терминал (cmd / PowerShell на Windows, Terminal на Mac) в папке с ботом:

```bash
# Перейди в папку проекта
cd путь/до/medbot

# Установи библиотеки
pip install -r requirements.txt
```

Если `pip` не найден — попробуй `pip3` или `python -m pip install -r requirements.txt`

---

### Шаг 5 — Запусти бота

```bash
python bot.py
```

На Mac:
```bash
python3 bot.py
```

В терминале появится:
```
2025-01-01 12:00:00 [INFO] Бот запущен. Нажми Ctrl+C для остановки.
```

Открой Telegram, найди своего бота по username и напиши `/start` 🎉

---

## СТРУКТУРА ПРОЕКТА

```
medbot/
├── bot.py              ← ТОЧКА ВХОДА. Здесь вставляешь токен и запускаешь
├── handlers.py         ← Все команды и кнопки бота
├── keyboards.py        ← Клавиатуры (кнопки)
├── messages.py         ← Тексты сообщений
├── requirements.txt    ← Список библиотек
├── .env.example        ← Пример файла с токеном
└── data/
    ├── clinics.py      ← ТЕСТОВЫЕ ДАННЫЕ клиник и цен (замени на реальные)
    └── storage.py      ← Хранение подписок пользователей (JSON-файл)
```

---

## КАК ПОДКЛЮЧИТЬ РЕАЛЬНЫЙ БЭКЕНД

Когда у тебя будет готов FastAPI бэкенд — замени функции в `data/clinics.py`.

Найди функцию `search_services` и замени тело:

```python
# БЫЛО (тестовые данные):
def search_services(service_name: str, city: str) -> list[dict]:
    results = []
    for clinic in CLINICS:
        ...
    return results

# СТАЛО (реальный API):
import httpx

def search_services(service_name: str, city: str) -> list[dict]:
    response = httpx.get(
        "http://localhost:8000/api/services/search",
        params={"q": service_name, "city": city}
    )
    return response.json()["results"]
```

Аналогично для `get_services_by_symptom`.

---

## КАК ДОБАВИТЬ НОВЫЕ КЛИНИКИ

Открой `data/clinics.py` и добавь новый объект в список `CLINICS`:

```python
{
    "id": 7,
    "name": "Название клиники",
    "city": "Алматы",          # Алматы / Астана / Шымкент
    "address": "ул. Примерная 1",
    "phone": "+7 727 000-00-00",
    "maps_url": "https://2gis.kz/almaty/search/НазваниеКлиники",
    "services": {
        "ОАК": 900,
        "УЗИ брюшной полости": 6500,
        # ... добавляй услуги из списка CLINICS[0]["services"]
    },
},
```

---

## КАК ДОБАВИТЬ НОВЫЙ ГОРОД

В `data/clinics.py` найди:
```python
CITIES = ["Алматы", "Астана", "Шымкент"]
```
Добавь город: `CITIES = ["Алматы", "Астана", "Шымкент", "Актобе"]`

Затем добавь клиники этого города в список `CLINICS`.

---

## КОМАНДЫ БОТА

| Команда | Действие |
|---------|----------|
| `/start` | Главное меню |
| `/search` | Поиск услуги по городу |
| `/symptom` | Подбор анализов по симптому |
| `/subs` | Мои подписки на цены |
| `/help` | Справка |

---

## ЧАСТЫЕ ОШИБКИ

**`ModuleNotFoundError: No module named 'aiogram'`**
→ Не установлены библиотеки. Запусти: `pip install -r requirements.txt`

**`ValueError: Токен бота не найден`**
→ Не вставил токен в `bot.py`. Открой файл и замени `ВСТАВЬ_ТОКЕН_СЮДА` на свой токен.

**`Telegram says: Unauthorized`**
→ Токен неправильный. Проверь что скопировал полностью из BotFather.

**Бот не отвечает**
→ Убедись что терминал с `python bot.py` открыт и работает. Бот работает пока открыт терминал.
