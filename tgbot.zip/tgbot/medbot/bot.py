"""
╔══════════════════════════════════════════╗
║      MedServicePrice.kz Telegram Bot     ║
║  Запуск:  python bot.py                  ║
╚══════════════════════════════════════════╝

Перед запуском:
1. Вставь токен бота в BOT_TOKEN ниже (или в .env)
2. pip install -r requirements.txt
3. python bot.py
"""

import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.memory import MemoryStorage

from handlers import router

# ─────────────────────────────────────────────────────────────────────────
#  👇 ВСТАВЬ СЮДА ТОКЕН ОТ @BotFather
# ─────────────────────────────────────────────────────────────────────────
BOT_TOKEN = "ВСТАВЬ_ТОКЕН_СЮДА"
# ─────────────────────────────────────────────────────────────────────────
#  Или используй .env файл:
#  Создай файл .env и напиши:  BOT_TOKEN=1234567890:твой_токен
#  Тогда строку выше можно оставить пустой
# ─────────────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


async def main():
    # Попробуй взять токен из .env если не вставлен напрямую
    token = BOT_TOKEN
    if token == "ВСТАВЬ_ТОКЕН_СЮДА":
        token = os.getenv("BOT_TOKEN", "")
    if not token:
        raise ValueError(
            "Токен бота не найден!\n"
            "Вставь его в bot.py в переменную BOT_TOKEN\n"
            "или создай файл .env с содержимым: BOT_TOKEN=твой_токен"
        )

    bot = Bot(
        token=token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    logger.info("Бот запущен. Нажми Ctrl+C для остановки.")
    await dp.start_polling(bot, skip_updates=True)


if __name__ == "__main__":
    asyncio.run(main())
