from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from data.clinics import CITIES, get_all_services


def city_keyboard() -> InlineKeyboardMarkup:
    buttons = [[InlineKeyboardButton(text=city, callback_data=f"city:{city}")]
               for city in CITIES]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def city_keyboard_for(prefix: str) -> InlineKeyboardMarkup:
    """Клавиатура выбора города с произвольным prefix для callback."""
    buttons = [[InlineKeyboardButton(text=city, callback_data=f"{prefix}:{city}")]
               for city in CITIES]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def services_keyboard(selected_city: str) -> InlineKeyboardMarkup:
    services = get_all_services()
    buttons = []
    row = []
    for i, svc in enumerate(services):
        row.append(InlineKeyboardButton(
            text=svc,
            callback_data=f"svc:{selected_city}:{svc}"
        ))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    buttons.append([InlineKeyboardButton(text="◀️ Назад", callback_data="back:main")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def subscribe_keyboard(service: str, city: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text=f"🔔 Подписаться на изменение цены",
            callback_data=f"sub:{city}:{service}"
        )],
        [InlineKeyboardButton(text="◀️ Главное меню", callback_data="back:main")],
    ])


def subscriptions_keyboard(subs: list[dict]) -> InlineKeyboardMarkup:
    buttons = []
    for s in subs:
        label = f"❌ {s['service']} · {s['city']}"
        buttons.append([InlineKeyboardButton(
            text=label,
            callback_data=f"unsub:{s['city']}:{s['service']}"
        )])
    buttons.append([InlineKeyboardButton(text="◀️ Назад", callback_data="back:main")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def main_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🔍 Найти услугу"), KeyboardButton(text="🤒 По симптому")],
            [KeyboardButton(text="🔔 Мои подписки"), KeyboardButton(text="ℹ️ О боте")],
        ],
        resize_keyboard=True,
    )
