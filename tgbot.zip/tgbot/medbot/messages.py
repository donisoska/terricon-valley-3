"""Функции форматирования сообщений бота."""


def format_clinic_results(service: str, results: list[dict]) -> str:
    if not results:
        return f"😔 По услуге <b>{service}</b> ничего не найдено в этом городе."

    cheapest = results[0]["price"]
    most_exp = results[-1]["price"]
    diff = round((most_exp - cheapest) / cheapest * 100) if cheapest else 0

    lines = [f"💊 <b>{service}</b>\n"]
    lines.append(f"📊 Найдено клиник: {len(results)}  |  Разброс цен: <b>{diff}%</b>\n")

    for i, r in enumerate(results):
        medal = ["🥇", "🥈", "🥉"][i] if i < 3 else "   "
        lines.append(
            f"{medal} <b>{r['clinic']}</b>\n"
            f"   💰 <b>{r['price']:,} тг</b>\n"
            f"   📍 {r['address']}\n"
            f"   📞 {r['phone']}\n"
            f"   🗺 <a href='{r['maps_url']}'>Открыть на карте</a>\n"
        )

    return "\n".join(lines)


def format_symptom_results(symptom: str, services_dict: dict) -> str:
    if not services_dict:
        return (
            f"🤔 По симптому <b>«{symptom}»</b> не нашлось совпадений.\n\n"
            f"Попробуй написать иначе, например: <i>голова, живот, сердце, кашель</i>"
        )

    lines = [f"🩺 По симптому <b>«{symptom}»</b> рекомендуем:\n"]
    for service, clinics in services_dict.items():
        if clinics:
            best = clinics[0]
            lines.append(
                f"▪️ <b>{service}</b>\n"
                f"   Лучшая цена: <b>{best['price']:,} тг</b> — {best['clinic']}\n"
                f"   🗺 <a href='{best['maps_url']}'>Открыть на карте</a>\n"
            )

    lines.append("\n💡 Нажми /search чтобы сравнить все клиники по конкретной услуге.")
    return "\n".join(lines)


def format_subscriptions(subs: list[dict]) -> str:
    if not subs:
        return (
            "🔔 У тебя пока нет подписок.\n\n"
            "Найди услугу через <b>🔍 Найти услугу</b> и подпишись на изменение цены."
        )
    lines = ["🔔 <b>Твои подписки:</b>\n"]
    lines.append("Нажми на позицию чтобы отписаться:\n")
    for s in subs:
        lines.append(f"• {s['service']} · {s['city']}")
    return "\n".join(lines)


ABOUT_TEXT = """
🏥 <b>MedServicePrice.kz Bot</b>

Помогаю быстро найти и сравнить цены на медицинские услуги в клиниках Казахстана.

<b>Что умею:</b>
🔍 Искать услуги по названию
🤒 Подбирать анализы по симптомам
🔔 Уведомлять об изменении цен
📍 Показывать клиники на карте

<b>Города:</b> Алматы, Астана, Шымкент

<b>Команды:</b>
/start — главное меню
/search — поиск услуги
/symptom — поиск по симптому
/subs — мои подписки
/help — помощь

💡 <i>Данные обновляются ежедневно</i>
"""
