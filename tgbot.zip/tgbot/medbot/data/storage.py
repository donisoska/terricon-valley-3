"""
Хранилище подписок пользователей.
Данные сохраняются в subscriptions.json рядом с этим файлом.
Когда подключишь БД — замени load/save на SQL-запросы.
"""

import json
import os

STORAGE_FILE = os.path.join(os.path.dirname(__file__), "subscriptions.json")


def _load() -> dict:
    if not os.path.exists(STORAGE_FILE):
        return {}
    with open(STORAGE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data: dict):
    with open(STORAGE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def add_subscription(user_id: int, service: str, city: str):
    data = _load()
    key = str(user_id)
    if key not in data:
        data[key] = []
    entry = {"service": service, "city": city}
    if entry not in data[key]:
        data[key].append(entry)
    _save(data)


def remove_subscription(user_id: int, service: str, city: str):
    data = _load()
    key = str(user_id)
    if key in data:
        data[key] = [
            s for s in data[key]
            if not (s["service"] == service and s["city"] == city)
        ]
    _save(data)


def get_subscriptions(user_id: int) -> list[dict]:
    data = _load()
    return data.get(str(user_id), [])


def get_all_subscriptions() -> dict:
    return _load()
