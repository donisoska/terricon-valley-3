"""
Все хэндлеры бота собраны здесь.
Роутер подключается в bot.py через dp.include_router(router)
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from data.clinics import search_services, get_services_by_symptom, CITIES
from data.storage import add_subscription, remove_subscription, get_subscriptions
from keyboards import (
    city_keyboard_for, services_keyboard, subscribe_keyboard,
    subscriptions_keyboard, main_menu_keyboard
)
from messages import (
    format_clinic_results, format_symptom_results,
    format_subscriptions, ABOUT_TEXT
)

router = Router()


# ── FSM States ────────────────────────────────────────────────────────────
class SearchStates(StatesGroup):
    waiting_city = State()
    waiting_service = State()


class SymptomStates(StatesGroup):
    waiting_city = State()
    waiting_symptom = State()


# ── /start ────────────────────────────────────────────────────────────────
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        f"👋 Привет, <b>{message.from_user.first_name}</b>!\n\n"
        "Я помогу найти и сравнить цены на медицинские услуги "
        "в клиниках Казахстана.\n\n"
        "Выбери действие в меню ниже 👇",
        parse_mode="HTML",
        reply_markup=main_menu_keyboard(),
    )


# ── /help ─────────────────────────────────────────────────────────────────
@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(ABOUT_TEXT, parse_mode="HTML")


# ── О боте ────────────────────────────────────────────────────────────────
@router.message(F.text == "ℹ️ О боте")
async def btn_about(message: Message):
    await message.answer(ABOUT_TEXT, parse_mode="HTML")


# ══════════════════════════════════════════════
#  ПОИСК УСЛУГИ
# ══════════════════════════════════════════════

@router.message(F.text == "🔍 Найти услугу")
@router.message(Command("search"))
async def cmd_search(message: Message, state: FSMContext):
    await state.set_state(SearchStates.waiting_city)
    await message.answer(
        "📍 В каком городе ищем?",
        reply_markup=city_keyboard_for("search_city"),
    )


@router.callback_query(F.data.startswith("search_city:"))
async def search_city_chosen(callback: CallbackQuery, state: FSMContext):
    city = callback.data.split(":")[1]
    await state.update_data(city=city)
    await state.set_state(SearchStates.waiting_service)
    await callback.message.edit_text(
        f"🏙 Город: <b>{city}</b>\n\nВыбери услугу из списка:",
        parse_mode="HTML",
        reply_markup=services_keyboard(city),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("svc:"))
async def service_chosen(callback: CallbackQuery, state: FSMContext):
    _, city, service = callback.data.split(":", 2)
    await state.clear()

    results = search_services(service, city)
    text = format_clinic_results(service, results)

    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=subscribe_keyboard(service, city),
        disable_web_page_preview=True,
    )
    await callback.answer()


# ══════════════════════════════════════════════
#  ПОИСК ПО СИМПТОМУ
# ══════════════════════════════════════════════

@router.message(F.text == "🤒 По симптому")
@router.message(Command("symptom"))
async def cmd_symptom(message: Message, state: FSMContext):
    await state.set_state(SymptomStates.waiting_city)
    await message.answer(
        "📍 В каком городе ищем?",
        reply_markup=city_keyboard_for("sym_city"),
    )


@router.callback_query(F.data.startswith("sym_city:"))
async def symptom_city_chosen(callback: CallbackQuery, state: FSMContext):
    city = callback.data.split(":")[1]
    await state.update_data(city=city)
    await state.set_state(SymptomStates.waiting_symptom)
    await callback.message.edit_text(
        f"🏙 Город: <b>{city}</b>\n\n"
        "✍️ Опиши симптом или часть тела:\n\n"
        "<i>Примеры: голова, живот, сердце, кашель, температура, рана, усталость</i>",
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(SymptomStates.waiting_symptom)
async def symptom_text_received(message: Message, state: FSMContext):
    data = await state.get_data()
    city = data.get("city", "Алматы")
    symptom = message.text.strip()
    await state.clear()

    services_dict = get_services_by_symptom(symptom, city)
    text = format_symptom_results(symptom, services_dict)

    await message.answer(
        text,
        parse_mode="HTML",
        disable_web_page_preview=True,
        reply_markup=main_menu_keyboard(),
    )


# ══════════════════════════════════════════════
#  ПОДПИСКИ
# ══════════════════════════════════════════════

@router.message(F.text == "🔔 Мои подписки")
@router.message(Command("subs"))
async def cmd_subs(message: Message):
    subs = get_subscriptions(message.from_user.id)
    text = format_subscriptions(subs)
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=subscriptions_keyboard(subs) if subs else None,
    )


@router.callback_query(F.data.startswith("sub:"))
async def subscribe(callback: CallbackQuery):
    _, city, service = callback.data.split(":", 2)
    add_subscription(callback.from_user.id, service, city)
    await callback.answer(f"✅ Подписка добавлена: {service} · {city}", show_alert=True)


@router.callback_query(F.data.startswith("unsub:"))
async def unsubscribe(callback: CallbackQuery):
    _, city, service = callback.data.split(":", 2)
    remove_subscription(callback.from_user.id, service, city)

    subs = get_subscriptions(callback.from_user.id)
    text = format_subscriptions(subs)
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=subscriptions_keyboard(subs) if subs else None,
    )
    await callback.answer(f"❌ Отписался от: {service}")


# ── Назад в главное меню ─────────────────────────────────────────────────
@router.callback_query(F.data == "back:main")
async def back_to_main(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("Главное меню 👇")
    await callback.message.answer(
        "Выбери действие:",
        reply_markup=main_menu_keyboard(),
    )
    await callback.answer()


# ── Fallback ──────────────────────────────────────────────────────────────
@router.message()
async def fallback(message: Message, state: FSMContext):
    current = await state.get_state()
    if current is None:
        await message.answer(
            "🤔 Не понял команду. Используй меню ниже 👇",
            reply_markup=main_menu_keyboard(),
        )
